﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Kovai.BizTalk360.CreateAlarms.BizTalkGroupServiceReference;
using Kovai.BizTalk360.CreateAlarms.Classes;
namespace Kovai.BizTalk360.CreateAlarms
{
    public partial class MainForm : Form
    {
        BizTalkEnvironmentSettings bizTalkEnvironmentSettings = null;
        public MainForm()
        {
            InitializeComponent();
        }
        private void BizTalkEnvsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadBizTalkEnvironments();
        }
        string ConstructSerializedConfig(OrchestrationCollection orchestrations, int expectedState)
        {
            string OrchestrationTemplate = "\"expectedState\":{0},\"setToExpectedState\":{1},\"maxAutoCorrectRetry\":{2},\"currentAutoCorrectCount\":{3},\"name\":\"{4}\",\"status\":{5},\"applicationName\":\"{6}\",\"assemblyQualifiedName\":\"{7}\",\"description\":\"{8}\",\"hostName\":\"{9}\"";

            string serializedConfigServiceLines = "";
            string serializedConfigServiceLine = "";

            int nrOfOchestrations = orchestrations.Count;

            for (int i = 0; i < nrOfOchestrations; i++)
            {
                BizTalkOrchestration bizTalkOrchestration = orchestrations[i];

                string status = "";
                switch (bizTalkOrchestration.status)
                {
                    case OrchestrationStatus.Bound:
                        {
                            status = "0";
                            break;
                        }
                    case OrchestrationStatus.Started:
                        {
                            status = "1";
                            break;
                        }
                    case OrchestrationStatus.Stopped:
                        {
                            status = "2";
                            break;
                        }
                    case OrchestrationStatus.Unbound:
                        {
                            status = "3";
                            break;
                        }
                }
                string host = (bizTalkOrchestration.host == null) ? "" : bizTalkOrchestration.host.name.ToString();
                serializedConfigServiceLine = String.Format(OrchestrationTemplate, expectedState.ToString(), "false", "0", "0", bizTalkOrchestration.name, status, bizTalkOrchestration.applicationName, bizTalkOrchestration.assemblyQualifiedName, bizTalkOrchestration.description, host);
                serializedConfigServiceLines += "{" + serializedConfigServiceLine + "},";
            }

            return "[" + serializedConfigServiceLines + "]";
            //return serializedConfigServiceLines;
        }
        string ConstructSerializedConfig(ReceivePortCollection receiveports, int expectedState)
        {
            string ReceiveLocationTemplate = "\"expectedState\":{0},\"setToExpectedState\":{1},\"maxAutoCorrectRetry\":{2},\"currentAutoCorrectCount\":{3},\"processMonitorConfigCollection\":null,\"name\":\"{4}\",\"receivePortName\":\"{5}\",\"address\":\"{6}\",\"isPrimary\":{7},\"isEnabled\":{8},\"isTwoWay\":{9}";
            string serializedConfigServiceLines = "";
            string serializedConfigServiceLine = "";

            int nrOfReceivePorts = receiveports.Count;

            for (int i = 0; i < nrOfReceivePorts; i++)
            {
                ReceivePort receiveport = receiveports[i];

                int nrOfReceiveLocations = receiveport.receiveLocations.Count;

                for (int j = 0; j < nrOfReceiveLocations; j++)
                {
                    ReceiveLocation receivelocation = receiveports[i].receiveLocations[j];
                    serializedConfigServiceLine = String.Format(ReceiveLocationTemplate, expectedState.ToString(), "false", "0", "0", receivelocation.name, receiveport.name, "", receivelocation.isPrimary.ToString().ToLower(), receivelocation.isEnabled.ToString().ToLower(), receivelocation.isTwoWay.ToString().ToLower());
                    serializedConfigServiceLines += "{" + serializedConfigServiceLine + "},";
                }
            }

            return "[" + serializedConfigServiceLines + "]";
        }
        private string ConstructSerializedConfig(BizTalkGroupServiceReference.SendPortCollection sendports, int expectedState)
        {
            string SendPortTemplate = "\"expectedState\":{0},\"setToExpectedState\":{1},\"maxAutoCorrectRetry\":{2},\"currentAutoCorrectCount\":{3},\"processMonitorConfigCollection\":null,\"name\":\"{4}\",\"status\":{5},\"isDynamic\":false,\"isTwoWay\":false,\"applicationName\":\"{6}\"";
            string serializedConfigServiceLines = "";
            string serializedConfigServiceLine = "";

            int nrOfSendPorts = sendports.Count;

            for (int i = 0; i < nrOfSendPorts; i++)
            {
                SendPort sendport = sendports[i];

                string status = "";
                switch (sendport.status)
                {
                    case PortStatus.Bound:
                        {
                            status = "0";
                            break;
                        }
                    case PortStatus.Started:
                        {
                            status = "1";
                            break;
                        }
                    case PortStatus.Stopped:
                        {
                            status = "2";
                            break;
                        }
                }
                serializedConfigServiceLine = String.Format(SendPortTemplate, expectedState.ToString(), "false", "0", "0", sendport.name, status, sendport.applicationName);
                serializedConfigServiceLines += "{" + serializedConfigServiceLine + "},";
            }

            return "[" + serializedConfigServiceLines + "]";
            //return serializedConfigServiceLines;
        }
        string CreateAlarmRequest(Alarm alarm)
        {
            Request request = new Request
            {
                context = new Context
                {
                    environmentSettings = new EnvironmentSettings
                    {
                        id = Guid.Parse(GetEnvironmentId()),
                        licenseEdition = 0
                    }
                },
                alarm = alarm
            };
            return JsonConvert.SerializeObject(request);
        }
        void CreateAlarms()
        {
            if (MessageBox.Show("Existing alarms will be deleted!\r\n\r\nDo you want to continue?", "Create Alarms", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation) != System.Windows.Forms.DialogResult.Yes)
            {
                return;
            }

            // Init some counters
            int nrOfAlarmsCreated = 0;
            int nrOfReceivePorts = 0;
            int nrOfOrchestrations = 0;
            int nrOfSendPorts = 0;
            string alarmId = string.Empty;
            DateTime startDateTime = DateTime.Now;

            // Load the current BizTalk360 Alarms for checking
            OutputTextBox.AppendText("Loading existing Alarms\r\n");
            UserAlarms userAlarms = LoadUserAlarms();

            // Retrieve all BizTalk Applications
            OutputTextBox.AppendText("Loading BizTalk Applications\r\n");
            BizTalkApplicationCollection bizTalkApplicationCollection = GetBizTalkApplications();

            OutputTextBox.AppendText(string.Format("BizTalk applications found: {0}\r\n\r\n", bizTalkApplicationCollection.Count));
            appProgressBar.Maximum = bizTalkApplicationCollection.Count;

            // Navigate through all BizTalk Applications and create alarms
            for (int i = 0; i < bizTalkApplicationCollection.Count; i++)
            {
                BizTalkApplication bizTalkApplication = bizTalkApplicationCollection[i];
                OutputTextBox.AppendText(string.Format("BizTalk application: {0}\r\n", bizTalkApplication.name));
                appProgressBar.Value = i + 1;

                // Get all Receive Ports
                ReceivePortCollection receivePorts = LoadReceivePorts(bizTalkApplication);

                // Get all Orchestrations
                OrchestrationCollection orchestrations = LoadOrchestrations(bizTalkApplication);

                // Get all Send Ports
                SendPortCollection sendPorts = LoadSendPorts(bizTalkApplication);

                // If the BizTalk Application contains no Receive Ports, Orchestrations or Send Ports, move on to the next BizTalk Application
                if (receivePorts.Count == 0 && orchestrations.Count == 0 && sendPorts.Count == 0)
                {
                    OutputTextBox.AppendText(String.Format("- No artifacts found => no alarm created\r\n\r\n"));
                    continue;
                }

                string response = "";
                if (userAlarms.Exists(x => x.name == bizTalkApplication.name))
                {
                    // Delete current alarm
                    OutputTextBox.AppendText(String.Format("- Alarm with name '{0}' already exist. It will be deleted\r\n", bizTalkApplication.name));
                    alarmId = userAlarms.FirstOrDefault(alarm => alarm.name == bizTalkApplication.name).alarmId;
                    string deleteRequest = CreateDeleteRequest(alarmId);
                    response = ProcessResponse(String.Format("{0}/Services.REST/AlertService.svc/DeleteUserAlarm", URLTextBox.Text), "POST", deleteRequest);
                    OutputTextBox.AppendText(String.Format("- Deleted alarm '{0}'\r\n", bizTalkApplication.name));
                }
                else
                {
                    OutputTextBox.AppendText(String.Format("- Alarm '{0}' does not yet exist. It will be created.\r\n", bizTalkApplication.name));
                }

                // Create User Alarm objects
                string request = CreateUserAlarm(bizTalkApplication);
                response = ProcessResponse(String.Format("{0}/Services.REST/AlertService.svc/CreateUserAlarm", URLTextBox.Text), "POST", request);
                OutputTextBox.AppendText(String.Format("- Created new alarm '{0}'\r\n", bizTalkApplication.name));
                //Updating the User Alarms after new Alarm Creation
                userAlarms = LoadUserAlarms();
                nrOfAlarmsCreated++;


                alarmId = userAlarms?.FirstOrDefault(al => al.name == bizTalkApplication.name).alarmId;

                if (!string.IsNullOrEmpty(alarmId))
                {
                    OutputTextBox.AppendText($"Alarm Name:{bizTalkApplication.name}, Alarm Id: {alarmId}"+ "\r\n");
                    int expectedState = 0;

                    // If the BizTalk Application contains Receive Ports, create Alarm Mappings
                    if (receivePorts.Count > 0)
                    {
                        switch (receiveLocationsExpectedStateComboBox.SelectedItem.ToString())
                        {
                            case "Enabled": { expectedState = 0; break; }
                            case "Disabled": { expectedState = 1; break; }
                            case "Do not monitor": { expectedState = 2; break; }
                        }

                        // Create Receive Ports mapping to the Alert
                        request = CreateReceiveLocationsMappings(alarmId, bizTalkApplication, receivePorts, expectedState);
                        OutputTextBox.AppendText(String.Format("- Adding {0} Receive Port(s) to alarm\r\n", receivePorts.Count));

                        // Create the Alarm mapping
                        response = ProcessResponse(String.Format("{0}/Services.REST/AlertService.svc/ManageAlertMonitorConfig", URLTextBox.Text), "POST", request);

                        nrOfReceivePorts += receivePorts.Count;

                        expectedState = 0;

                        // If the BizTalk Application contains Orchestrations, create Alarm Mappings
                        if (orchestrations.Count > 0)
                        {

                            switch (orchestrationsExpectedStateComboBox.SelectedItem.ToString())
                            {
                                case "Unbound": { expectedState = 1; break; }
                                case "Started": { expectedState = 2; break; }
                                case "Stopped": { expectedState = 3; break; }
                                case "Unenlisted": { expectedState = 0; break; }
                                case "Do not monitor": { expectedState = 4; break; }
                            }

                            // Create Orchestration mapping to the Alert
                            request = CreateOrchestrationMappings(alarmId, bizTalkApplication, orchestrations, expectedState);
                            OutputTextBox.AppendText(String.Format("- Adding {0} Orchestration(s) to alarm\r\n", orchestrations.Count));

                            // Create the Alarm mapping
                            response = ProcessResponse(String.Format("{0}/Services.REST/AlertService.svc/ManageAlertMonitorConfig", URLTextBox.Text), "POST", request);

                            nrOfOrchestrations += orchestrations.Count;
                        }

                        expectedState = 0;

                        // If the BizTalk Application contains Send Ports, create Alarm Mappings
                        if (sendPorts.Count > 0)
                        {

                            switch (sendPortsExpectedStateComboBox.SelectedItem.ToString())
                            {
                                case "Started": { expectedState = 2; break; }
                                case "Stopped": { expectedState = 3; break; }
                                case "Unenlisted": { expectedState = 0; break; }
                                case "Do not monitor": { expectedState = 1; break; }
                            }

                            // Create Send Port mapping to the Alert
                            request = CreateSendPortMappings(alarmId, bizTalkApplication, sendPorts, expectedState);
                            OutputTextBox.AppendText(String.Format("- Adding {0} Send Port(s) to alarm\r\n", sendPorts.Count));

                            // Create the Alarm mapping
                            response = ProcessResponse(String.Format("{0}/Services.REST/AlertService.svc/ManageAlertMonitorConfig", URLTextBox.Text), "POST", request);

                            nrOfSendPorts += sendPorts.Count;
                        }

                        OutputTextBox.AppendText("\r\n");
                    }
                }
                else
                {
                    OutputTextBox.AppendText($"Alarm Id is null for the alarm name {bizTalkApplication.name}\r\n");
                }
            }

            DateTime endDateTime = DateTime.Now;
            TimeSpan durationTimeSpan = endDateTime.Subtract(startDateTime);
            OutputTextBox.AppendText(string.Format("Finished!\r\n{0} alarms created for\r\n- {1} BizTalk applications containing\r\n  - {2} Receive Ports\r\n  - {3} Orchestrations\r\n  - {4} Send Ports\r\n  - Duration: {5}", nrOfAlarmsCreated, bizTalkApplicationCollection.Count, nrOfReceivePorts, nrOfOrchestrations, nrOfSendPorts, durationTimeSpan.ToString(@"hh\:mm\:ss")));

        }
        string CreateBizTalk360ServiceURL(string service, string operation)
        {
            string domainName = URLTextBox.Text;
            string url = domainName.EndsWith("/") ? string.Format("{0}Services.REST/{1}/{2}", domainName, service, operation) : string.Format("{0}/Services.REST/{1}/{2}", domainName, service, operation);
            return url;
        }
        string CreateDeleteRequest(string alarmName)
        {
            DeleteRequest request = new DeleteRequest
            {
                context = new Context
                {
                    callerReference = "REST-SAMPLE",
                    environmentSettings = new EnvironmentSettings
                    {
                        id = Guid.Parse(GetEnvironmentId()),
                        licenseEdition = 0
                    }
                },
                alarmName = alarmName
            };
            return JsonConvert.SerializeObject(request);
        }
        private string CreateOrchestrationMappings(string alarmId, BizTalkApplication bizTalkapplication, OrchestrationCollection orchestrations, int expectedState)
        {

            OrchestrationMappingRequest request = new OrchestrationMappingRequest
            {
                context = new Context
                {
                    callerReference = "ORCHESTRATION-MAPPING",
                    environmentSettings = new EnvironmentSettings
                    {
                        id = Guid.Parse(GetEnvironmentId()),
                        licenseEdition = 0
                    }
                },
                monitorGroupName = bizTalkapplication.name,
                monitorGroupType = "Application",
                monitorName = "Orchestrations",
                operation = 0,
                alarmId = alarmId,
                //serializedMonitorConfigforApplicationOrchestration = ConstructSerializedConfig(orchestrations, expectedState),
                serializedJsonMonitorConfig = ConstructSerializedConfig(orchestrations, expectedState),
                comment = string.Empty
            };
            /*
                   	serializedMonitorConfigforApplicationServiceInstance = "",
                    serializedMonitorConfigforApplicationOrchestration = ConstructSerializedConfig(orchestrations),
	                serializedMonitorConfigforApplicationReceiveLocation="",
	                serializedMonitorConfigforApplicationSendPorts="",
	                serializedMonitorConfigforBizTalkServerDisks="",
	                serializedMonitorConfigforBizTalkSystemResources="",
	                serializedMonitorConfigforBizTalkEventLogs="",
	                serializedMonitorConfigforBizTalkNTServices="",
	                serializedMonitorConfigforSQLServerDisks="",
	                serializedMonitorConfigforSQLSystemResources="",
	                serializedMonitorConfigforSQLEventLogs="",
	                serializedMonitorConfigforSQLNTServices="",
	                serializedMonitorConfigforSQLInstanceJobs="",
	                serializedMonitorConfigforHostInstances="",
	                serializedMonitorConfigforWebEndPoints="",
	                serializedMonitorConfigforDatabaseQuery="",
                    serializedMonitorConfigforMessageBoxViewer = ""

             */


            return JsonConvert.SerializeObject(request);
        }
        string CreateReceiveLocationsMappings(string alarmId, BizTalkApplication bizTalkapplication, ReceivePortCollection receivePorts, int expectedState)
        {

            ReceiveLocationMappingRequest request = new ReceiveLocationMappingRequest
            {
                context = new Context
                {
                    callerReference = "RECEIVELOCATION-MAPPING",
                    environmentSettings = new EnvironmentSettings
                    {
                        id = Guid.Parse(GetEnvironmentId()),
                        licenseEdition = 0
                    }
                },
                monitorGroupName = bizTalkapplication.name,
                monitorGroupType = "Application",
                monitorName = "ReceiveLocations",
                operation = 0,
                alarmId = alarmId,
                serializedJsonMonitorConfig = ConstructSerializedConfig(receivePorts, expectedState),
                comment = string.Empty
            };

            return JsonConvert.SerializeObject(request);
        }
        private string CreateSendPortMappings(string alarmId, BizTalkApplication bizTalkapplication, SendPortCollection sendports, int expectedState)
        {

            SendPortMappingRequest request = new SendPortMappingRequest
            {
                context = new Context
                {
                    callerReference = "SENDPORTS-MAPPING",
                    environmentSettings = new EnvironmentSettings
                    {
                        id = Guid.Parse(GetEnvironmentId()),
                        licenseEdition = 0
                    }
                },
                monitorGroupName = bizTalkapplication.name,
                monitorGroupType = "Application",
                monitorName = "SendPorts",
                operation = 0,
                alarmId = alarmId,
                //serializedMonitorConfigforApplicationSendPorts = ConstructSerializedConfig(sendports, expectedState),
                serializedJsonMonitorConfig = ConstructSerializedConfig(sendports, expectedState),
                comment = string.Empty
            };

            return JsonConvert.SerializeObject(request);
        }
        private string CreateUserAlarm(BizTalkApplication biztalkApplication)
        {
            // Create User Alarm objects
            Alarm alarm = new Alarm
            {
                alertASAPErrorDetectionCount = 0,
                alertASAPWaitDurationInMinutes = (int)violationUpDown.Value,
                alertResetDurationInMinutes= 0,
                commaSeparatedEmails = emailIDsTextBox.Text,
                commaSeparatedSMSNumbers = "",
                continuousErrorMaxCount = (int)limitAlertsUpDown.Value,
                createdBy = "",
                daysOfWeek = new Classes.DaysOfWeek { Fri = false, Mon = false, Sat = false, Sun = false, Thu = false, Tue = false, Wed = false },
                daysValidation = "day",
                description = String.Format("Alarm for application {0}", biztalkApplication.name),
                emailTemplateId = GetDefaultEmailTempateId(),
                emailTemplateName = "BizTalk360 Email Template",
                errorsCount= 0,
                eventId = "",
                isAlertASAP = true,
                isAlertDisabled = !enableAlarmCheckBox.Checked,
                isAlertEventVwrEnabled = false,
                isAlertHealthMonitoring = false,
                isAlertHPOMEnabled = false,
                isAlertOnCorrection = notifyWhenNormalCheckBox.Checked,
                isAlertProcessMonitoring = false,
                isAlertProcessMonitoringOnSuccess = false,
                isAlertRestEndpointEnabled = false,
                isContinuousErrorRestricted = true,
                isTestMode = false,
                isThresholdRestricted = false,
                name = biztalkApplication.name,
                notificationChannels = new List<string>(),
                thresholdDaysOfWeek = new Classes.DaysOfWeek { Fri = false, Mon = false, Sat = false, Sun = false, Thu = false, Tue = false, Wed = false },
                thresholdRestrictStartTime = "/Date(-62227800000+0000)/",
                thresholdRestrictEndTime = "/Date(-62227800000+0000)/",
                timeOfDays = new Classes.TimeOfDays { Eight = false, Eighteen = false, Eleven = false, Fifteen = false, Five = false, Four = false, Fourteen = false, Nine = false, Nineteen = false, One = false, Seven = false, Seventeen = false, Six = false, Sixteen = false, Ten = false, Thirteen = false, Three = false, Twelve = false, Twenty = false, TwentyOne = false, TwentyThree = false, TwentyTwo = false, Two = false, Zero = false },
                warningsCount= 0
            };

            // Create the Request
            string request = CreateAlarmRequest(alarm);

            return request;
        }
        BizTalkApplicationCollection GetBizTalkApplications()
        {
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            httpClientHandler.UseDefaultCredentials = true;

            using (HttpClient client = new HttpClient(httpClientHandler))
            {
                client.BaseAddress = new Uri(CreateBizTalk360ServiceURL("BizTalkGroupService.svc", "GetBizTalkApplicationsList"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Retrieve the environment Id
                string envId = GetEnvironmentId();

                if (string.IsNullOrEmpty(envId))
                {
                    MessageBox.Show("Unable to retrieve the current environment.", "Create Alarms", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return (null);
                }

                string urlParms = string.Format("?environmentId={0}", envId);

                HttpResponseMessage httpResponseMessage = client.GetAsync(urlParms).Result;
                if (httpResponseMessage.IsSuccessStatusCode)
                {
                    var getBizTalkApplicationsListResponse = httpResponseMessage.Content.ReadAsAsync<GetBizTalkApplicationsListResponse>().Result;

                    if (getBizTalkApplicationsListResponse.success)
                    {
                        return getBizTalkApplicationsListResponse.biztalkApplications;
                    }
                }
                return null;
            }
        }
        string GetEnvironmentId()
        {
            // Go through all retrieved environments
            for (int i = 0; i < bizTalkEnvironmentSettings.Count; i++)
            {
                // If environment found, return Id.
                if (bizTalkEnvironmentSettings[i].name == BizTalkEnvsComboBox.Text)
                {
                    return bizTalkEnvironmentSettings[i].id.ToString();
                }
            }
            return null;
        }
        void LoadBizTalkEnvironments()
        {
            // Retrieve BizTalk Environments which are managed from BizTalk360
            OutputTextBox.AppendText("Get all configured BizTalk360 environments\r\n");

            HttpClientHandler httpClientHandler = new HttpClientHandler();
            httpClientHandler.UseDefaultCredentials = true;

            using (HttpClient httpClient = new HttpClient(httpClientHandler))
            {
                httpClient.BaseAddress = new Uri(CreateBizTalk360ServiceURL("AdminService.svc", "GetAllConfiguredEnvironments"));
                OutputTextBox.AppendText(String.Format("- Base Address: {0}\r\n", httpClient.BaseAddress.ToString()));
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage httpResponseMessage = httpClient.GetAsync("").Result;
                if (httpResponseMessage.IsSuccessStatusCode)
                {
                    var getAllConfiguredEnvironmentsResponse = httpResponseMessage.Content.ReadAsAsync<GetAllConfiguredEnvironmentsResponse>().Result;
                    if (getAllConfiguredEnvironmentsResponse.success)
                    {

                        // Store for later use
                        bizTalkEnvironmentSettings = getAllConfiguredEnvironmentsResponse.biztalkEnvironments;

                        BizTalkEnvsComboBox.Items.Clear();
                        if (bizTalkEnvironmentSettings.Count > 0)
                        {
                            foreach (BizTalkEnvironmentSetting bizTalkEnvironmentSetting in bizTalkEnvironmentSettings)
                            {
                                BizTalkEnvsComboBox.Items.Add(bizTalkEnvironmentSetting.name);
                            }

                            BizTalkEnvsComboBox.SelectedIndex = 0;
                            OutputTextBox.AppendText(String.Format("- {0} environment(s) found\r\n", bizTalkEnvironmentSettings.Count));
                        }
                        else
                        {
                            BizTalkEnvsComboBox.Items.Add("<No BizTalk Environments found>");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)httpResponseMessage.StatusCode, httpResponseMessage.ReasonPhrase);
                    OutputTextBox.AppendText(string.Format("- {0} ({1})\r\n", (int)httpResponseMessage.StatusCode, httpResponseMessage.ReasonPhrase));
                }

                OutputTextBox.AppendText("\r\n");
            }
        }
        int GetDefaultEmailTempateId()
        {
            // Load the Default BizTalk360 Default EmailTemplateId

            try
            {
                HttpClientHandler httpClientHandler = new HttpClientHandler();
                httpClientHandler.UseDefaultCredentials = true;

                using (HttpClient httpClient = new HttpClient(httpClientHandler))
                {
                    httpClient.BaseAddress = new Uri(CreateBizTalk360ServiceURL("AdminService.svc", "GetEmailTemplates"));
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                    HttpResponseMessage httpResponseMessage = httpClient.GetAsync(string.Empty).Result;
                    if (httpResponseMessage.IsSuccessStatusCode)
                    {
                        var getEmailTemplatesResponse = httpResponseMessage.Content.ReadAsAsync<GetEmailTemplatesResponse>().Result;
                        if (getEmailTemplatesResponse.success)
                        {
                            return (int)(getEmailTemplatesResponse.emailTemplateList.Where(template => template.isDefaultTemplate).FirstOrDefault()?.id);
                        }
                    }

                }
            }
            catch (Exception)
            {
                return (default(int));
            }

            return default(int);


        }

        OrchestrationCollection LoadOrchestrations(BizTalkGroupServiceReference.BizTalkApplication biztalkApplication)
        {
            HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;

            using (HttpClient client = new HttpClient(handler))
            {
                // Construct the base address of the service.
                client.BaseAddress = new Uri(CreateBizTalk360ServiceURL("BizTalkApplicationService.svc", "GetOrchestrations"));

                // Add an Accept header for JSON format.
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Retrieve the environment Id
                string environmentId = GetEnvironmentId();

                // Check if environmentId is populated
                if (string.IsNullOrEmpty(environmentId))
                {
                    // Set the default cursor
                    Cursor = Cursors.Default;
                    return (null);
                }

                string urlParameters = string.Format("?environmentId={0}", environmentId);

                // List data response.
                HttpResponseMessage response = client.GetAsync(string.Format("{0}&applicationName={1}", urlParameters, biztalkApplication.name)).Result;
                if (response.IsSuccessStatusCode)
                {
                    // Do something with result
                    var getOrchestrationsResponse = response.Content.ReadAsAsync<GetOrchestrationsResponse>().Result;
                    if (getOrchestrationsResponse.success)
                    {
                        // Return the result.
                        return getOrchestrationsResponse.orchestrations;
                    }
                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
                return null;
            }
        }
        ReceivePortCollection LoadReceivePorts(BizTalkApplication biztalkApplication)
        {
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            httpClientHandler.UseDefaultCredentials = true;

            using (HttpClient httpClient = new HttpClient(httpClientHandler))
            {
                httpClient.BaseAddress = new Uri(CreateBizTalk360ServiceURL("BizTalkApplicationService.svc", "GetReceivePorts"));
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string envId = GetEnvironmentId();

                // Check if environmentId is populated
                if (string.IsNullOrEmpty(envId))
                {
                    return (null);
                }

                string urlParms = string.Format("?environmentId={0}", envId);

                HttpResponseMessage response = httpClient.GetAsync(string.Format("{0}&applicationName={1}", urlParms, biztalkApplication.name)).Result;
                if (response.IsSuccessStatusCode)
                {
                    var getReceivePortsResponse = response.Content.ReadAsAsync<GetReceivePortsResponse>().Result;
                    if (getReceivePortsResponse.success)
                    {
                        return getReceivePortsResponse.receivePorts;
                    }
                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
                return null;
            }
        }
        SendPortCollection LoadSendPorts(BizTalkGroupServiceReference.BizTalkApplication biztalkApplication)
        {
            HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;

            using (HttpClient client = new HttpClient(handler))
            {
                // Construct the base address of the service.
                client.BaseAddress = new Uri(CreateBizTalk360ServiceURL("BizTalkApplicationService.svc", "GetSendPorts"));

                // Add an Accept header for JSON format.
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Retrieve the environment Id
                string environmentId = GetEnvironmentId();

                // Check if environmentId is populated
                if (string.IsNullOrEmpty(environmentId))
                {
                    // Set the default cursor
                    Cursor = Cursors.Default;
                    return (null);
                }

                string urlParameters = string.Format("?environmentId={0}", environmentId);

                // List data response.
                HttpResponseMessage response = client.GetAsync(string.Format("{0}&applicationName={1}", urlParameters, biztalkApplication.name)).Result;
                if (response.IsSuccessStatusCode)
                {
                    // Do something with result
                    var getSendPortsResponse = response.Content.ReadAsAsync<GetSendPortsResponse>().Result;
                    if (getSendPortsResponse.success)
                    {
                        // Return the result.
                        return getSendPortsResponse.sendPorts;
                    }
                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
                return null;
            }
        }
        UserAlarms LoadUserAlarms()
        {
            // Load the current BizTalk360 Useralarms

            HttpClientHandler httpClientHandler = new HttpClientHandler();
            httpClientHandler.UseDefaultCredentials = true;

            using (HttpClient httpClient = new HttpClient(httpClientHandler))
            {
                httpClient.BaseAddress = new Uri(CreateBizTalk360ServiceURL("AlertService.svc", "GetUserAlarms"));
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string envId = GetEnvironmentId();

                // Check if environmentId is populated
                if (string.IsNullOrEmpty(envId))
                {
                    // Set the default cursor
                    Cursor = Cursors.Default;
                    return (null);
                }

                string urlParms = string.Format("?environmentId={0}", envId);
                HttpResponseMessage httpResponseMessage = httpClient.GetAsync(urlParms).Result;
                try
                {
                    GetUserAlarmsResponse getUserAlarmsResponse = new GetUserAlarmsResponse();
                    if (httpResponseMessage.IsSuccessStatusCode)
                    {
                         getUserAlarmsResponse = httpResponseMessage.Content.ReadAsAsync<GetUserAlarmsResponse>().Result;
                        if (getUserAlarmsResponse.success)
                        {
                            return (getUserAlarmsResponse.userAlarms);
                        }
                    }
                    else {

                        OutputTextBox.AppendText($" Sucess(True / False): {getUserAlarmsResponse.success.ToString()}  Error: { getUserAlarmsResponse.errors.ToString()} \r\n");
                    }

                }
                catch(Exception ex)
                {
                    if(ex.InnerException != null)
                    OutputTextBox.AppendText(ex.Message +  ex.InnerException  + "\r\n");
                    else
                    OutputTextBox.AppendText(ex.Message + "\r\n");
                }

                return (null);
            }

        }
        public string ProcessResponse(string url, string method, string data)
        {
            WebRequest request = WebRequest.Create(url);
            request.Credentials = new NetworkCredential(SuperUserAccountTextBox.Text, SuperUserPasswordTextBox.Text);
            request.Method = method;
            string postData = data;
            request.ContentType = "application/json";
            request.ContentLength = data.Length;
            using (Stream webStream = request.GetRequestStream())
            using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
                requestWriter.Write(data);

            // Response Object
            WebResponse response = request.GetResponse();
            string responseFromServer = "";
            using (Stream webStream = response.GetResponseStream())
            {
                if (webStream != null)
                {
                    using (StreamReader responseReader = new StreamReader(webStream))
                    {
                        responseFromServer = responseReader.ReadToEnd();
                        responseReader.Close();
                    }
                }
            }
            response.Close();
            return (responseFromServer);
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            URLTextBox.Text = Properties.Settings.Default.BizTalk360URL;
            SuperUserAccountTextBox.Text = Properties.Settings.Default.SU_Account;
            SuperUserPasswordTextBox.Text = Properties.Settings.Default.SU_Password;

            enableAlarmCheckBox.Checked = Properties.Settings.Default.Alarm_Enable;
            emailIDsTextBox.Text = Properties.Settings.Default.Alarm_Emails;
            violationUpDown.Value = Properties.Settings.Default.Alarm_Violation;
            limitAlertsUpDown.Value = Properties.Settings.Default.Alarm_Limits;
            notifyWhenNormalCheckBox.Checked = Properties.Settings.Default.Alarm_NotifyNormal;

            receiveLocationsExpectedStateComboBox.Text = Properties.Settings.Default.Exp_RL;
            sendPortsExpectedStateComboBox.Text = Properties.Settings.Default.Exp_SP;
            orchestrationsExpectedStateComboBox.Text = Properties.Settings.Default.Exp_SP;

            BizTalkEnvsComboBox.SelectedIndex = 0;
        }
        private void loadBizTalkEnvsButton_Click(object sender, EventArgs e)
        {
            LoadBizTalkEnvironments();
        }
        private void createAlarmsButton_Click(object sender, EventArgs e)
        {
            if (bizTalkEnvironmentSettings != null && bizTalkEnvironmentSettings.Any())
                CreateAlarms();
            else
                MessageBox.Show("Please Select the Environment to Create Alarms");
        }
    }
}
