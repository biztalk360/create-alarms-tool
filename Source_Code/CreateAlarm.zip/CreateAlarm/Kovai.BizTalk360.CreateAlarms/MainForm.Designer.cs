﻿namespace Kovai.BizTalk360.CreateAlarms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.loadBizTalkEnvsButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.BizTalkEnvsComboBox = new System.Windows.Forms.ComboBox();
            this.SuperUserPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuperUserAccountTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.URLTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.OutputTextBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.orchestrationsExpectedStateComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.sendPortsExpectedStateComboBox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.receiveLocationsExpectedStateComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.emailIDsTextBox = new System.Windows.Forms.TextBox();
            this.notifyWhenNormalCheckBox = new System.Windows.Forms.CheckBox();
            this.limitAlertsUpDown = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.violationUpDown = new System.Windows.Forms.NumericUpDown();
            this.enableAlarmCheckBox = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.createAlarmsButton = new System.Windows.Forms.Button();
            this.appProgressBar = new System.Windows.Forms.ProgressBar();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limitAlertsUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.violationUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.loadBizTalkEnvsButton);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.BizTalkEnvsComboBox);
            this.groupBox1.Controls.Add(this.SuperUserPasswordTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.SuperUserAccountTextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.URLTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 30);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(549, 173);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "BizTalk360 Settings";
            // 
            // loadBizTalkEnvsButton
            // 
            this.loadBizTalkEnvsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadBizTalkEnvsButton.Location = new System.Drawing.Point(485, 127);
            this.loadBizTalkEnvsButton.Margin = new System.Windows.Forms.Padding(4);
            this.loadBizTalkEnvsButton.Name = "loadBizTalkEnvsButton";
            this.loadBizTalkEnvsButton.Size = new System.Drawing.Size(53, 30);
            this.loadBizTalkEnvsButton.TabIndex = 4;
            this.loadBizTalkEnvsButton.Text = "...";
            this.loadBizTalkEnvsButton.UseVisualStyleBackColor = true;
            this.loadBizTalkEnvsButton.Click += new System.EventHandler(this.loadBizTalkEnvsButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 134);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "BizTalk Environments";
            // 
            // BizTalkEnvsComboBox
            // 
            this.BizTalkEnvsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BizTalkEnvsComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BizTalkEnvsComboBox.FormattingEnabled = true;
            this.BizTalkEnvsComboBox.Items.AddRange(new object[] {
            "<Click button to load BizTalk environments>"});
            this.BizTalkEnvsComboBox.Location = new System.Drawing.Point(222, 127);
            this.BizTalkEnvsComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.BizTalkEnvsComboBox.Name = "BizTalkEnvsComboBox";
            this.BizTalkEnvsComboBox.Size = new System.Drawing.Size(255, 28);
            this.BizTalkEnvsComboBox.TabIndex = 3;
            // 
            // SuperUserPasswordTextBox
            // 
            this.SuperUserPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SuperUserPasswordTextBox.Location = new System.Drawing.Point(222, 92);
            this.SuperUserPasswordTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.SuperUserPasswordTextBox.Name = "SuperUserPasswordTextBox";
            this.SuperUserPasswordTextBox.PasswordChar = '*';
            this.SuperUserPasswordTextBox.Size = new System.Drawing.Size(317, 27);
            this.SuperUserPasswordTextBox.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 99);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Super User Password";
            // 
            // SuperUserAccountTextBox
            // 
            this.SuperUserAccountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SuperUserAccountTextBox.Location = new System.Drawing.Point(222, 57);
            this.SuperUserAccountTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.SuperUserAccountTextBox.Name = "SuperUserAccountTextBox";
            this.SuperUserAccountTextBox.Size = new System.Drawing.Size(317, 27);
            this.SuperUserAccountTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 62);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Super User Account";
            // 
            // URLTextBox
            // 
            this.URLTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.URLTextBox.Location = new System.Drawing.Point(222, 26);
            this.URLTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.URLTextBox.Name = "URLTextBox";
            this.URLTextBox.Size = new System.Drawing.Size(316, 27);
            this.URLTextBox.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 33);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "URL BizTalk360";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.appProgressBar);
            this.groupBox2.Controls.Add(this.OutputTextBox);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(583, 31);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(515, 555);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Output";
            // 
            // OutputTextBox
            // 
            this.OutputTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OutputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutputTextBox.Location = new System.Drawing.Point(8, 61);
            this.OutputTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.OutputTextBox.Multiline = true;
            this.OutputTextBox.Name = "OutputTextBox";
            this.OutputTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.OutputTextBox.Size = new System.Drawing.Size(499, 486);
            this.OutputTextBox.TabIndex = 0;
            this.OutputTextBox.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.orchestrationsExpectedStateComboBox);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.sendPortsExpectedStateComboBox);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.receiveLocationsExpectedStateComboBox);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.emailIDsTextBox);
            this.groupBox3.Controls.Add(this.notifyWhenNormalCheckBox);
            this.groupBox3.Controls.Add(this.limitAlertsUpDown);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.violationUpDown);
            this.groupBox3.Controls.Add(this.enableAlarmCheckBox);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(13, 214);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(551, 290);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Alarm Settings";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(9, 253);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 20);
            this.label10.TabIndex = 14;
            this.label10.Text = "Expected state Orchs";
            // 
            // orchestrationsExpectedStateComboBox
            // 
            this.orchestrationsExpectedStateComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.orchestrationsExpectedStateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orchestrationsExpectedStateComboBox.FormattingEnabled = true;
            this.orchestrationsExpectedStateComboBox.Items.AddRange(new object[] {
            "Unbound",
            "Started",
            "Stopped",
            "Unenlisted",
            "Do not monitor"});
            this.orchestrationsExpectedStateComboBox.Location = new System.Drawing.Point(222, 249);
            this.orchestrationsExpectedStateComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.orchestrationsExpectedStateComboBox.Name = "orchestrationsExpectedStateComboBox";
            this.orchestrationsExpectedStateComboBox.Size = new System.Drawing.Size(316, 28);
            this.orchestrationsExpectedStateComboBox.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 222);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(160, 20);
            this.label9.TabIndex = 12;
            this.label9.Text = "Expected state SP\'s";
            // 
            // sendPortsExpectedStateComboBox
            // 
            this.sendPortsExpectedStateComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.sendPortsExpectedStateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendPortsExpectedStateComboBox.FormattingEnabled = true;
            this.sendPortsExpectedStateComboBox.Items.AddRange(new object[] {
            "Started",
            "Stopped",
            "Unenlisted",
            "Do not monitor"});
            this.sendPortsExpectedStateComboBox.Location = new System.Drawing.Point(222, 215);
            this.sendPortsExpectedStateComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.sendPortsExpectedStateComboBox.Name = "sendPortsExpectedStateComboBox";
            this.sendPortsExpectedStateComboBox.Size = new System.Drawing.Size(316, 28);
            this.sendPortsExpectedStateComboBox.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 188);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "Expected state RL\'s";
            // 
            // receiveLocationsExpectedStateComboBox
            // 
            this.receiveLocationsExpectedStateComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.receiveLocationsExpectedStateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.receiveLocationsExpectedStateComboBox.FormattingEnabled = true;
            this.receiveLocationsExpectedStateComboBox.Items.AddRange(new object[] {
            "Disabled",
            "Do Not Monitor",
            "Enabled"});
            this.receiveLocationsExpectedStateComboBox.Location = new System.Drawing.Point(222, 182);
            this.receiveLocationsExpectedStateComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.receiveLocationsExpectedStateComboBox.Name = "receiveLocationsExpectedStateComboBox";
            this.receiveLocationsExpectedStateComboBox.Size = new System.Drawing.Size(316, 28);
            this.receiveLocationsExpectedStateComboBox.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 56);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Email ID\'s";
            // 
            // emailIDsTextBox
            // 
            this.emailIDsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.emailIDsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailIDsTextBox.Location = new System.Drawing.Point(222, 50);
            this.emailIDsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.emailIDsTextBox.Multiline = true;
            this.emailIDsTextBox.Name = "emailIDsTextBox";
            this.emailIDsTextBox.Size = new System.Drawing.Size(317, 29);
            this.emailIDsTextBox.TabIndex = 1;
            // 
            // notifyWhenNormalCheckBox
            // 
            this.notifyWhenNormalCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.notifyWhenNormalCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.notifyWhenNormalCheckBox.Checked = true;
            this.notifyWhenNormalCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.notifyWhenNormalCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notifyWhenNormalCheckBox.Location = new System.Drawing.Point(9, 154);
            this.notifyWhenNormalCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.notifyWhenNormalCheckBox.Name = "notifyWhenNormalCheckBox";
            this.notifyWhenNormalCheckBox.Size = new System.Drawing.Size(232, 27);
            this.notifyWhenNormalCheckBox.TabIndex = 4;
            this.notifyWhenNormalCheckBox.Text = "Notify when Normal";
            this.notifyWhenNormalCheckBox.UseVisualStyleBackColor = true;
            // 
            // limitAlertsUpDown
            // 
            this.limitAlertsUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.limitAlertsUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limitAlertsUpDown.Location = new System.Drawing.Point(222, 120);
            this.limitAlertsUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.limitAlertsUpDown.Name = "limitAlertsUpDown";
            this.limitAlertsUpDown.Size = new System.Drawing.Size(90, 27);
            this.limitAlertsUpDown.TabIndex = 3;
            this.limitAlertsUpDown.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 124);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Limit alerts";
            // 
            // violationUpDown
            // 
            this.violationUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.violationUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.violationUpDown.Location = new System.Drawing.Point(222, 87);
            this.violationUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.violationUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.violationUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.violationUpDown.Name = "violationUpDown";
            this.violationUpDown.Size = new System.Drawing.Size(90, 27);
            this.violationUpDown.TabIndex = 2;
            this.violationUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // enableAlarmCheckBox
            // 
            this.enableAlarmCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enableAlarmCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enableAlarmCheckBox.Location = new System.Drawing.Point(9, 22);
            this.enableAlarmCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.enableAlarmCheckBox.Name = "enableAlarmCheckBox";
            this.enableAlarmCheckBox.Size = new System.Drawing.Size(230, 25);
            this.enableAlarmCheckBox.TabIndex = 0;
            this.enableAlarmCheckBox.Text = "Enable Alarm";
            this.enableAlarmCheckBox.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 91);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Violation (minutes)";
            // 
            // createAlarmsButton
            // 
            this.createAlarmsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.createAlarmsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createAlarmsButton.Location = new System.Drawing.Point(29, 512);
            this.createAlarmsButton.Margin = new System.Windows.Forms.Padding(4);
            this.createAlarmsButton.Name = "createAlarmsButton";
            this.createAlarmsButton.Size = new System.Drawing.Size(522, 74);
            this.createAlarmsButton.TabIndex = 0;
            this.createAlarmsButton.Text = "Create Alarms";
            this.createAlarmsButton.UseVisualStyleBackColor = true;
            this.createAlarmsButton.Click += new System.EventHandler(this.createAlarmsButton_Click);
            // 
            // appProgressBar
            // 
            this.appProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.appProgressBar.Location = new System.Drawing.Point(8, 28);
            this.appProgressBar.Name = "appProgressBar";
            this.appProgressBar.Size = new System.Drawing.Size(499, 24);
            this.appProgressBar.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1111, 593);
            this.Controls.Add(this.createAlarmsButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(800, 640);
            this.Name = "MainForm";
            this.Text = "BizTalk360 - Create Alarms";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limitAlertsUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.violationUpDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox SuperUserPasswordTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox SuperUserAccountTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox URLTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox BizTalkEnvsComboBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox OutputTextBox;
        private System.Windows.Forms.Button loadBizTalkEnvsButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox notifyWhenNormalCheckBox;
        private System.Windows.Forms.NumericUpDown limitAlertsUpDown;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown violationUpDown;
        private System.Windows.Forms.CheckBox enableAlarmCheckBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox emailIDsTextBox;
        private System.Windows.Forms.ComboBox receiveLocationsExpectedStateComboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox orchestrationsExpectedStateComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox sendPortsExpectedStateComboBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button createAlarmsButton;
        private System.Windows.Forms.ProgressBar appProgressBar;
    }
}