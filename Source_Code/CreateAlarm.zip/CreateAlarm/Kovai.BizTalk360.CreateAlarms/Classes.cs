﻿using System;
using System.Collections.Generic;

namespace Kovai.BizTalk360.CreateAlarms.Classes
{
    public class Alarm
    {
        public string name { get; set; }
        public string commaSeparatedEmails { get; set; }
        public string commaSeparatedSMSNumbers { get; set; }
        public bool isTestMode { get; set; }
        public bool isAlertASAP { get; set; }
        public int alertASAPWaitDurationInMinutes { get; set; }
        public int alertASAPErrorDetectionCount { get; set; }
        public bool isContinuousErrorRestricted { get; set; }
        public int continuousErrorMaxCount { get; set; }
        public bool isAlertOnCorrection { get; set; }
        public DaysOfWeek daysOfWeek { get; set; }
        public TimeOfDays timeOfDays { get; set; }
        public bool isAlertProcessMonitoring { get; set; }
        public bool isAlertProcessMonitoringOnSuccess { get; set; }
        public bool isAlertHealthMonitoring { get; set; }
        public bool isAlertHPOMEnabled { get; set; }
        public bool isAlertRestEndpointEnabled { get; set; }
        public bool isAlertEventVwrEnabled { get; set; }
        public string eventId { get; set; }
        public bool isAlertDisabled { get; set; }
        public string createdBy { get; set; }
        public string description { get; set; }
        public bool isThresholdRestricted { get; set; }
        public string thresholdRestrictStartTime { get; set; }
        public string thresholdRestrictEndTime { get; set; }
        public string daysValidation { get; set; }
        public DaysOfWeek thresholdDaysOfWeek { get; set; }
        public List<String> notificationChannels { get; set; }
        public int emailTemplateId { get; set; }
    }
    public class Context
    {
        public string callerReference { get; set; }
        public EnvironmentSettings environmentSettings { get; set; }
    }
    public class DaysOfWeek
    {
        public bool Mon { get; set; }
        public bool Tue { get; set; }
        public bool Wed { get; set; }
        public bool Thu { get; set; }
        public bool Fri { get; set; }
        public bool Sat { get; set; }
        public bool Sun { get; set; }
    }
    public class DeleteRequest
    {
        public Context context { get; set; }
        public String alarmName { get; set; }
    }
    public class EnvironmentSettings
    {
        public Guid id { get; set; }
        public int licenseEdition { get; set; }
    }
    public class OrchestrationMappingRequest
    {
        public Context context { get; set; }
        public Int16 operation { get; set; }
        public string monitorGroupName { get; set; }
        public string monitorGroupType { get; set; }
        public string monitorName { get; set; }
        public string alarmId { get; set; }
        public string serializedMonitorConfigforApplicationServiceInstance { get; set; }
        public string serializedMonitorConfigforApplicationOrchestration { get; set; }
        public string serializedMonitorConfigforApplicationReceiveLocation { get; set; }
        public string serializedMonitorConfigforApplicationSendPorts { get; set; }
        public string serializedMonitorConfigforBizTalkServerDisks { get; set; }
        public string serializedMonitorConfigforBizTalkSystemResources { get; set; }
        public string serializedMonitorConfigforBizTalkEventLogs { get; set; }
        public string serializedMonitorConfigforBizTalkNTServices { get; set; }
        public string serializedMonitorConfigforSQLServerDisks { get; set; }
        public string serializedMonitorConfigforSQLSystemResources { get; set; }
        public string serializedMonitorConfigforSQLEventLogs { get; set; }
        public string serializedMonitorConfigforSQLNTServices { get; set; }
        public string serializedMonitorConfigforSQLInstanceJobs { get; set; }
        public string serializedMonitorConfigforHostInstances { get; set; }
        public string serializedMonitorConfigforWebEndPoints { get; set; }
        public string serializedMonitorConfigforDatabaseQuery { get; set; }
        public string serializedMonitorConfigforMessageBoxViewer { get; set; }
        public string serializedJsonMonitorConfig { get; set; }
    }
    public class ReceiveLocationMappingRequest
    {
        public Context context { get; set; }
        public Int16 operation { get; set; }
        public string monitorGroupName { get; set; }
        public string monitorGroupType { get; set; }
        public string monitorName { get; set; }
        public string alarmId { get; set; }
        public string serializedMonitorConfigforApplicationServiceInstance { get; set; }
        public string serializedMonitorConfigforApplicationOrchestration { get; set; }
        public string serializedMonitorConfigforApplicationReceiveLocation { get; set; }
        public string serializedMonitorConfigforApplicationSendPorts { get; set; }
        public string serializedMonitorConfigforBizTalkServerDisks { get; set; }
        public string serializedMonitorConfigforBizTalkSystemResources { get; set; }
        public string serializedMonitorConfigforBizTalkEventLogs { get; set; }
        public string serializedMonitorConfigforBizTalkNTServices { get; set; }
        public string serializedMonitorConfigforSQLServerDisks { get; set; }
        public string serializedMonitorConfigforSQLSystemResources { get; set; }
        public string serializedMonitorConfigforSQLEventLogs { get; set; }
        public string serializedMonitorConfigforSQLNTServices { get; set; }
        public string serializedMonitorConfigforSQLInstanceJobs { get; set; }
        public string serializedMonitorConfigforHostInstances { get; set; }
        public string serializedMonitorConfigforWebEndPoints { get; set; }
        public string serializedMonitorConfigforDatabaseQuery { get; set; }
        public string serializedMonitorConfigforMessageBoxViewer { get; set; }
        public string serializedJsonMonitorConfig { get; set; }
    }
    public class Request
    {
        public Context context { get; set; }
        public Alarm alarm { get; set; }
    }
    public class SendPortMappingRequest
    {
        public Context context { get; set; }
        public Int16 operation { get; set; }
        public string monitorGroupName { get; set; }
        public string monitorGroupType { get; set; }
        public string monitorName { get; set; }
        public string alarmId { get; set; }
        public string serializedMonitorConfigforApplicationServiceInstance { get; set; }
        public string serializedMonitorConfigforApplicationOrchestration { get; set; }
        public string serializedMonitorConfigforApplicationReceiveLocation { get; set; }
        public string serializedMonitorConfigforApplicationSendPorts { get; set; }
        public string serializedMonitorConfigforBizTalkServerDisks { get; set; }
        public string serializedMonitorConfigforBizTalkSystemResources { get; set; }
        public string serializedMonitorConfigforBizTalkEventLogs { get; set; }
        public string serializedMonitorConfigforBizTalkNTServices { get; set; }
        public string serializedMonitorConfigforSQLServerDisks { get; set; }
        public string serializedMonitorConfigforSQLSystemResources { get; set; }
        public string serializedMonitorConfigforSQLEventLogs { get; set; }
        public string serializedMonitorConfigforSQLNTServices { get; set; }
        public string serializedMonitorConfigforSQLInstanceJobs { get; set; }
        public string serializedMonitorConfigforHostInstances { get; set; }
        public string serializedMonitorConfigforWebEndPoints { get; set; }
        public string serializedMonitorConfigforDatabaseQuery { get; set; }
        public string serializedMonitorConfigforMessageBoxViewer { get; set; }
        public string serializedJsonMonitorConfig { get; set; }
    }
    public class TimeOfDays
    {
        public bool Zero { get; set; }
        public bool One { get; set; }
        public bool Two { get; set; }
        public bool Three { get; set; }
        public bool Four { get; set; }
        public bool Five { get; set; }
        public bool Six { get; set; }
        public bool Seven { get; set; }
        public bool Eight { get; set; }
        public bool Nine { get; set; }
        public bool Ten { get; set; }
        public bool Eleven { get; set; }
        public bool Twelve { get; set; }
        public bool Thirteen { get; set; }
        public bool Fourteen { get; set; }
        public bool Fifteen { get; set; }
        public bool Sixteen { get; set; }
        public bool Seventeen { get; set; }
        public bool Eighteen { get; set; }
        public bool Nineteen { get; set; }
        public bool Twenty { get; set; }
        public bool TwentyOne { get; set; }
        public bool TwentyTwo { get; set; }
        public bool TwentyThree { get; set; }
    }
}
